// 'use client';
// import { useEffect, useState } from 'react';

// const WebStory = () => {
  
//   const [story, setStory] = useState([{
//         author : "John Doe",
//         category   :   "Travel",
//         created_at   :   "December 20, 2024",
//         id   : 1,
//         thumbnail: "https://unsplash.com/photos/a-group-of-people-walking-down-a-street-next-to-tall-buildings-lUaRej89CIQ",
//         title: "Top 4 Must-Visit Destinations in India 2024",
//         pages: [
//     {description: 'The Taj Mahal, an ivory-white marble mausoleum on … tomb is the centerpiece of a 17-hectare complex.', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=1000&auto=format&fit=crop', page_number: 1, title: 'Taj Mahal - The Symbol of Love'}
//     ,
//     {description: 'Varanasi, the spiritual capital of India, is the h…the citys winding streets are some 2,000 temples.', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=1000&auto=format&fit=crop', page_number: 2, title: 'Varanasi - The Spiritual Capital'}
//     ,
//     {description: 'The Kerala backwaters are a network of interconnec…e rivers meets the seawater from the Arabian Sea.', media_type: 'image', media_url: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1000&auto=format&fit=crop', page_number: 3, title: 'Kerala Backwaters - Venice of the East'}
//     ,
//     {description: 'Rajasthan, the largest state of India, is widely f…emples, palaces, and forts built by Rajput kings.', media_type: 'image', media_url: "https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=1000&auto=format&fit=crop",page_number: 4, title: "Rajasthan - The Land of Kings"}
      
//     ]
      
//       }]);
//       // console.log();
      
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const loadStory = async () => {
//       try {
//         setLoading(true);
//         // // Fetch all stories first
//         // const response = await fetch('http://localhost:8080/api/stories');
        
//         // if (!response.ok) {
//         //   throw new Error(`HTTP error! status: ${response.status}`);
//         // }
        
//         // const stories = await response.json();
//         // // Get the first story from the list
//         // if (stories && stories.length > 0) {
//         //   // Fetch the full story details using the first story's slug
//         //   const storyResponse = await fetch(`http://localhost:8080/api/stories/${stories[0].slug}`);
//         //   if (!storyResponse.ok) {
//         //     throw new Error(`HTTP error! status: ${storyResponse.status}`);
//         //   }
//         //   const storyData = await storyResponse.json();
//           console.log('Story data:', story);
//           // setStory(storyData);
//         // } else {
//         //   throw new Error('No stories found');
//         // }

//         // Load AMP scripts
//         const script = document.createElement('script');
//         script.async = true;
//         script.src = 'https://cdn.ampproject.org/v0.js';
//         document.body.appendChild(script);

//         const ampStoryScript = document.createElement('script');
//         ampStoryScript.async = true;
//         ampStoryScript.custom_element = "amp-story";
//         ampStoryScript.src = 'https://cdn.ampproject.org/v0/amp-story-1.0.js';
//         document.body.appendChild(ampStoryScript);
//       } catch (err) {
//         console.error('Error loading story:', err);
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     loadStory();
//   }, []);

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center min-h-screen">
//         <div className="text-xl">Loading story...</div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="flex items-center justify-center min-h-screen">
//         <div className="text-xl text-red-600">
//           Error loading story: {error}
//         </div>
//       </div>
//     );
//   }

//   if (!story) {
//     return (
//       <div className="flex items-center justify-center min-h-screen">
//         <div className="text-xl">Story not found</div>
//       </div>
//     );
//   }

//   return (
//     <div className="webstory-container">
//       <amp-story
//         standalone=""
//         title={story[0].title}
//         publisher="Your Publisher Name"
//         publisher-logo-src={story[0].thumbnail}
//         poster-portrait-src={ story[0].thumbnail}
//       >
//         {/* Cover Page */}
//         <amp-story-page id="cover">
//           <amp-story-grid-layer template="fill">
//             <amp-img
//               src={story[0].thumbnail}
//               width="720"
//               height="1280"
//               layout="responsive"
//               alt={story[0].title}
//             />
//           </amp-story-grid-layer>
//           <amp-story-grid-layer template="vertical" class="bottom">
//             <div className="p-8">
//               <h1 className="text-4xl font-bold text-white mb-4">{story[0].title}</h1>
//               <div className="flex items-center text-white">
//                 <span className="mr-4">{story[0].author}</span>
//                 <span>{story[0].created_at}</span>
//               </div>
//             </div>
//           </amp-story-grid-layer>
//         </amp-story-page>

//         {/* Story Pages */}
//         {story[0].pages?.map((page, index) => (
//           <amp-story-page id={`page-${index + 1}`} key={index}>
//             <amp-story-grid-layer template="fill">
//               {page.media_type === 'image' ? (
//                 <amp-img
//                   src={page.media_url}
//                   width="720"
//                   height="1280"
//                   layout="responsive"
//                   alt={page.title}
//                 />
//               ) : (
//                 <amp-video
//                   autoplay=""
//                   loop=""
//                   width="720"
//                   height="1280"
//                   poster={story[0].thumbnail }
//                   layout="responsive"
//                 >
//                   <source src={page.media_url} type="video/mp4" />
//                 </amp-video>
//               )}
//             </amp-story-grid-layer>
//             <amp-story-grid-layer template="vertical" class="bottom">
//               <div className="p-8">
//                 <h2 className="text-3xl font-bold text-white mb-4">{page.title}</h2>
//                 <p className="text-lg text-white">{page.description}</p>
//               </div>
//             </amp-story-grid-layer>
//           </amp-story-page>
//         ))}
//       </amp-story>

     
//     </div>
//   );
// };

// export default WebStory;