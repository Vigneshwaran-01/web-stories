// app/data/tickPoints.ts
export const tickPoints = [
    "Integer tincidunt consectetur",
    "Phasellus tristique",
    "Erat diam interdum purus, vel",
    "Eget vehicula nulla facilisi phasellus",
    "Mauris interdum diam",
    "Mauris blandit erat vel dolor",
    "Sollicitudin ut dapibus neque lacinia",
    "Fusce imperdiet nisl quis eleifend",
    "Curabitur sit amet arcu",
    "Morbi in venenatis enim ipsum",
  ];
  