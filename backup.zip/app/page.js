import KnowledgeBase from './components/KnowledgeBase';

export default function Home() {
  return <KnowledgeBase />;
}



