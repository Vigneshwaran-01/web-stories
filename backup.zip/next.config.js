module.exports = {
  amp: {
    canonicalBase: 'https://yoursite.com',
  },
} 